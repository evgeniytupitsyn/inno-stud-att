# gradle-docker-plugin

Gradle plugin to define and orchestrate Docker images.
