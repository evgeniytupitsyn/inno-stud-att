package net.praqma.docker.connection;

public enum EventName {

	create, destroy, die, export, kill, pause, restart, start, stop, unpause	
}
