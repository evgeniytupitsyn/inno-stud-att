/**
 * Created by Nikolay on 24.11.2016.
 */
$(document).ready(function(){
    $('#students').DataTable();
    $('#lectures').DataTable();
    $('#journal').DataTable();
});