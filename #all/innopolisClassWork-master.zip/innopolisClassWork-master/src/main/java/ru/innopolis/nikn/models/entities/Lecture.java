package ru.innopolis.nikn.models.entities;

/**
 * Created by Nikolay on 28.11.2016.
 */
public class Lecture {

    private int id;
    private String name;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
