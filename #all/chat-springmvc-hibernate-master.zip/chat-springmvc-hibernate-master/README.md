A sample application with Spring (MVC, Security), Hibernate and JQuery
