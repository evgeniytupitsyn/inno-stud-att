package space.zhdanov;

/**
 * Created by nikolai on 15.11.16.
 */
public interface Executable {

    void execute(String[] args);
}
