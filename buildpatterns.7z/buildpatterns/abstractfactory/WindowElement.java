package ru.innopolis.uni.course2.buildpatterns.abstractfactory;

/**
 * Created by d.sapaev on 21.11.2016.
 */
public interface WindowElement {
    public void show();
}
