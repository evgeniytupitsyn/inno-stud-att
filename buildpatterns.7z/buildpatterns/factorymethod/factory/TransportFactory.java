package ru.innopolis.uni.course2.buildpatterns.factorymethod.factory;

import ru.innopolis.uni.course2.buildpatterns.factorymethod.Transport;

/**
 * Created by d.sapaev on 21.11.2016.
 */
public interface TransportFactory {
    public Transport factoryMethod();
}
