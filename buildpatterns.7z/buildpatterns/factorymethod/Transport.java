package ru.innopolis.uni.course2.buildpatterns.factorymethod;

/**
 * Created by d.sapaev on 21.11.2016.
 */
public interface Transport {
    public void transport(Object cargo);
}
