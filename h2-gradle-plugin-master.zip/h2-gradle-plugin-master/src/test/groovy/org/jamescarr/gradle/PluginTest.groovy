package org.jamescarr.gradle

import static org.junit.Assert.*;

import org.junit.Test;

public class PluginTest {

	@Test
	public void test() {
	}

}
