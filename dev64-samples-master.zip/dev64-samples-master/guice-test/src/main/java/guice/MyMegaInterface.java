package guice;

/**
 */
public interface MyMegaInterface {
    void run();
}
