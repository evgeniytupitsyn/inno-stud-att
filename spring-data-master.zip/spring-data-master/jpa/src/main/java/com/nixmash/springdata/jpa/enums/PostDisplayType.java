package com.nixmash.springdata.jpa.enums;

/**
 * Created by daveburke on 6/1/16.
 */
public enum PostDisplayType {
    LINK,
    LINK_SUMMARY,
    LINK_FEATURE,
    POST,
    NIXMASH_POST,
    MULTIPHOTO_POST,
    SINGLEPHOTO_POST
}




