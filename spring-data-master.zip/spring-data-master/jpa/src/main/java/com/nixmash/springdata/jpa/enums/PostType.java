package com.nixmash.springdata.jpa.enums;

/**
 * Created by daveburke on 6/1/16.
 */
public enum PostType {
    LINK,
    POST,
    UNDEFINED
}
