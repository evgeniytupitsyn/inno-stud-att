package com.nixmash.springdata.jpa.enums;

/**
 * Created by daveburke on 7/20/16.
 */
public final class ContentType {
    public static final int POST = 1;
}

