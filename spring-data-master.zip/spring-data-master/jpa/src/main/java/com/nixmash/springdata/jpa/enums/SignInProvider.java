package com.nixmash.springdata.jpa.enums;

public enum SignInProvider {
	SITE,
    FACEBOOK,
    TWITTER,
    GOOGLE
}
