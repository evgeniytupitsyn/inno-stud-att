package com.nixmash.springdata.mvc.containers;

public class PostLink implements java.io.Serializable {


	private static final long serialVersionUID = 9063998456473593040L;

	public PostLink() {}

	private  String link;

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link= link;
	}
	
}

