package com.nixmash.springdata.jsoup.parsers;

import com.nixmash.springdata.jsoup.base.JsoupHtmlParser;
import com.nixmash.springdata.jsoup.dto.PagePreviewDTO;

public class PagePreviewParser extends JsoupHtmlParser<PagePreviewDTO> {

    public PagePreviewParser(Class<PagePreviewDTO> classModel) {
        super(classModel);
    }

}







