# pairTraining-service
Project Innopolis.
