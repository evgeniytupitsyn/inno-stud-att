alter table account alter column firstname set not null;
alter table account alter column lastname set not null;
alter table account alter column email set not null;